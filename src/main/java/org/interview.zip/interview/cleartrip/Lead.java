package org.interview.cleartrip;

public class Lead extends User {

    public Lead(String name) {
        super(name);
    }
}
