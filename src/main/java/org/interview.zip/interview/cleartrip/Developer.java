package org.interview.cleartrip;

public class Developer extends User{
    String assignedProjectId;

    public Developer(String name) {
        super(name);
    }
}
