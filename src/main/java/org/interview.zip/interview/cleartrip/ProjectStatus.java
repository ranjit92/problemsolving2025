package org.interview.cleartrip;

public enum ProjectStatus {
    OPEN,
    REQUESTED,
    ASSIGNED,
    IN_PROGRESS,
    COMPLETED,
    CANCELLED
}
