package org.interview.cleartrip;

public class ProjectRequest {
    String id;
    String developerId;
    String projectId;

    public ProjectRequest(String id, String developerId, String projectId) {
        this.id = id;
        this.developerId = developerId;
        this.projectId = projectId;
    }
}
