package org.interview.cleartrip;

public enum ProjectCategory {
    FRONTEND,
    BACKEND,
    AIML,
    BIGDATA,
}
