package org.example.opentable;

public enum TypeOfCoffee {

    LATTE,
    BLACK_COFFEE;
}
