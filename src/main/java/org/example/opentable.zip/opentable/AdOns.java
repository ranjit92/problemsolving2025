package org.example.opentable;

public enum AdOns {
    SUGAR,
    CREAM;

}
