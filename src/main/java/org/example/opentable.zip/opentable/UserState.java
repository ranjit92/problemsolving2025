package org.example.opentable;

public enum UserState {
    SELECTION,
    COFFEE_DES,
    NONE;
}
